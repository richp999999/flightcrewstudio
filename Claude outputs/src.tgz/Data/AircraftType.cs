using System.ComponentModel.DataAnnotations;
using Microsoft.EntityFrameworkCore;

namespace FlightCrewStudio.Data;

/// <summary>
/// An aircraft type (e.g. "A-321" by "AIRBUS"). <see cref="Aircraft"/> rows link to it by
/// <see cref="Aircraft.AircraftTypeId"/>. One set of types per user; sync adds new types it meets.
/// </summary>
[Index(nameof(UserId), nameof(Name), IsUnique = true)]
public class AircraftType
{
    public int Id { get; set; }

    [Required]
    public string UserId { get; set; } = default!;
    public ApplicationUser? User { get; set; }

    /// <summary>Type/model, e.g. "A-321".</summary>
    [Required, MaxLength(50)]
    public string Name { get; set; } = default!;

    /// <summary>Manufacturer, e.g. "AIRBUS".</summary>
    [MaxLength(50)]
    public string? Manufacturer { get; set; }

    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;

    public string DisplayName => Manufacturer is null ? Name : $"{Name} ({Manufacturer})";
}
